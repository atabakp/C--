#include "stdafx.h"
#include "Monthly.h"


Monthly::Monthly()
{
}
