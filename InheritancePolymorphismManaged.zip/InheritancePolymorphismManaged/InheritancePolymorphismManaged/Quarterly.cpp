#include "stdafx.h"
#include "Quarterly.h"


Quarterly::Quarterly()
{
}
