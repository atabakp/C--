#pragma once
#include "SelfFunded.h"
ref class Monthly :
	public SelfFunded
{
public:
	Monthly();
};

