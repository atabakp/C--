#include "stdafx.h"
#include "Local.h"


Local::Local()
{
}
