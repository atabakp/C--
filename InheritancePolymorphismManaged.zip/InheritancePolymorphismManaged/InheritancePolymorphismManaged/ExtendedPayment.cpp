#include "stdafx.h"
#include "ExtendedPayment.h"


ExtendedPayment::ExtendedPayment()
{
}
