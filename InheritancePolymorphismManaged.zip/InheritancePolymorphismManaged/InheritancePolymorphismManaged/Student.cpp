#include "stdafx.h"
#include "Student.h"


Student::Student()
{
}
