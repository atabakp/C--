#include "stdafx.h"
#include "SelfFunded.h"


SelfFunded::SelfFunded()
{
}
