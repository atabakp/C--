#pragma once
#include "SelfFunded.h"
ref class Quarterly :
	public SelfFunded
{
public:
	Quarterly();
};

